﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jira.Rest.Sdk.Dtos
{
    public partial class Progress
    {
        public long ProgressProgress { get; set; }
        public long Total { get; set; }
    }
}
